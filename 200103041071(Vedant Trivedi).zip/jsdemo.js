function ExternalAlert(){
    alert('internal alert')
}
function ExternalPrompt(){
    na=prompt('external alert')
    alert('hi'+na)
}
function ExternalConfirm(){
    confirm('external confirm')
}